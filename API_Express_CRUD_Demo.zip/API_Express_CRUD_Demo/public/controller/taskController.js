const taskModule = angular.module('taskApp',[])
taskModule.controller('taskCtrl',function($scope,$http){
    $scope.task=[]
    $scope.newTask={} //Add data
    $scope.updateTask={} //update data
    $scope.addstat=0
    $scope.editstat=0
    $scope.click=0
    // Function to read data
    $scope.getTask = function(){
        $http.get('/api/getTaskDetails').then(function(response){
            $scope.task=response.data;
        })
    }
    // Function to Add data
    $scope.addTask = function(){
        $http.post('/api/addTask',$scope.newTask).then(function(response){
            $scope.msg = response.data.message
        })
        $scope.getTask()
    }
    // Function to Delete Data
    $scope.deleteTask = function(id){
        $http.delete(`/api/deleteTask/${id}`).then(function(response){
            $scope.msg = response.data.message
        })
        $scope.getTask()
    }
    // Function to Edit Data
    $scope.editTask = function(id,item){
        $scope.editstat=1
        $scope.id=id
        $scope.click= $scope.click+1;
        if($scope.click== 2){
            $scope.data=item
            $http.put(`/api/editTask/${id}`,item).then(function(response){
                $scope.msg = response.data.message
        })
            $scope.getTask()
            $scope.click=0
        }
        

    }
    $scope.getTask()

    


})